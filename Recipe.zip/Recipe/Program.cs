﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;


// Ingredient class represents an ingridient with a name, quantity and unit of measurement
class Ingredient
{
    public string Name { get; set; }

    public double Quantity { get; set; }

    public string Unit { get; set; }

    public Ingredient(string name, double quantity, string unit)
    {
        Name = name;
        Quantity = quantity;
        Unit = unit;
    }
}

// Recipe class represents a recipe with a name, list of ingredients, and list of steps
class Recipe
{
    public string Name { get; set; }
    private List<Ingredient> Ingredients { get; set; }
    private List<string> Steps { get; set; }
    private List<Ingredient> OriginalQuantities { get; set; }

    // Constructor initialises the recipe with a name and empty lists for ingredients and steps.
    public Recipe(string name)
    {
        Name = name;
        Ingredients = new List<Ingredient>();
        Steps = new List<string>();
        OriginalQuantities = new List<Ingredient>();
    }

    // AddIngredient method adds a new ingredient to the recipe.
    public void AddIngredient(Ingredient ingredient)
    {
        Ingredients.Add(ingredient);
        //Store original quantity for scaling purposes
        OriginalQuantities.Add(new Ingredient(ingredient.Name, ingredient.Quantity, ingredient.Unit));
    }
    //AddStep Method adds a new step to the recipe
    public void AddStep(string step)
    {
        Steps.Add(step);
    }
    // DisplayRecipe method displays the recipe including all the ingredients and steps.
    public void DisplayRecipe()
    {
        Console.WriteLine($"Recipe: {Name} \n");
        Console.WriteLine("Ingredients:");
        foreach (var ingredient in Ingredients)
        {
            Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
        }
        Console.WriteLine("\nSteps:");
        for (int i = 0; i < Steps.Count; i++)
        {
            Console.WriteLine($"{i + 1}.{Steps[i]}");
        }
    }
    //ScaleRecipe method scales the quantities of all the ingredients by a given factor.
    public void ScaleRecipe(double factor)
    {
        foreach (var ingredient in Ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }
    //ResetQuantities method resets all ingredient quantities to their original values.
    public void ResetQuantities()
    {
        for (int i = 0; i <Ingredients.Count; i++)
        {
            Ingredients[i].Quantity = OriginalQuantities[i].Quantity;
        }
    }
    //ClearData methods clears all recipe data.
    public void ClearData()
    {
        Ingredients.Clear();
        Steps.Clear();
        OriginalQuantities.Clear();
    }
}

class Program
{
    //Main Method is the entry point of the program
    static void Main(string[] args)
    {
        Recipe recipe = null;

        while (true)
        {
            //Display Menu:
            Console.WriteLine("1. Enter Recipe Details");
            Console.WriteLine("2. Display Full Recipe");
            Console.WriteLine("3. Scale Recipe");
            Console.WriteLine("4. Reset Quantities");
            Console.WriteLine("5. Clear Data");
            Console.WriteLine("6. Exit Menu");
            Console.Write("\nEnter your choice: ");

            int choice;

            //Validate user input
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 6)
            {
                Console.WriteLine("Invalid input. Please enter a number between 1 and 6.");
                Console.Write("Enter Your Choice: ");
            }
            switch (choice)
            {
                case 1:
                    recipe = EnterRecipeDetails();

                    break;
                case 2:
                    DisplayRecipe(recipe);

                    break;

                case 3:
                    ScaleRecipe(recipe);

                    break;

                case 4:
                    ResetQuantites(recipe);

                    break;

                case 5:
                    ClearData(recipe);
                    recipe = null;
                    break;

                case 6:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    //EnterRecipeDetails method prompts the user to enter details of a recipe and returns the created recipe.
    static Recipe EnterRecipeDetails()
    {
        Console.Write("Enter recipe name: ");

        string name = Console.ReadLine();

        Recipe recipe = new Recipe(name);

        int numIngredients = 0;

        //Validate number of ingredients 
        while (true)
        {
            Console.Write("Enter number of ingredients: ");

            if (int.TryParse(Console.ReadLine(), out numIngredients) && numIngredients > 0)
            {
                break;
            }
            Console.WriteLine("Invalid input. Please enter a positive integer");
        }
        for (int i = 0; i < numIngredients; i++)
        {
            string ingridientName;
            double quantity;
            string unit;

            while (true)
            {
                Console.Write($"Enter name of ingredient {1 + 1}: ");

                ingridientName = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(ingridientName))

                {
                    break;
                }
                Console.WriteLine("Ingredient name cannot be empty");
            }
            while (true)
            {

                Console.Write($"Enter quantity of : ");

                if (double.TryParse(Console.ReadLine(), out quantity) && quantity > 0)
                {
                    break;
                }
                Console.WriteLine("Invalid input. Please enter a positive number.");
            }
            Console.Write($"Enter unit of measurement for : ");
            unit = Console.ReadLine();

            string ingredientName = null;
            recipe.AddIngredient(new Ingredient(ingredientName, quantity, unit));
        }
        int numSteps = 0;
        //Validate number of steps
        while (true)
        {

            Console.Write("Enter number of steps: ");

            if (int.TryParse(Console.ReadLine(), out numSteps)&& numSteps > 0)
            {
                break;
            }
            Console.WriteLine("Invalid input. Please enter a positive integer.");
        }
        for (int i = 0; i < numSteps; i++)
        {
            Console.Write($"Enter Step {i + 1}: ");
            string step = Console.ReadLine();
            recipe.AddStep(step);
        }
        Console.WriteLine("Recipe details have been entered successfully.");
        return recipe;
    }

    //DisplayRecipe method displays the details of a given recipe.

    static void DisplayRecipe(Recipe recipe)
    {
        if (recipe == null)
        {
            Console.WriteLine("No recipe entered yet.");
            return;
        }
        recipe.DisplayRecipe();
    }
    //ScaleRecipe method scales the quantities of the ingredients given recipe by a factor specified by the user.
    static void ScaleRecipe(Recipe recipe)
    {
        if (recipe == null)
        {
            Console.WriteLine("No recipe entered yet.");
            return;
        }
        Console.Write("Enter scaling form (0.5, 2, 0r 3): ");
        double factor;

        //Validate scaling factor
        while (true)
        {
            if (double.TryParse(Console.ReadLine(), out factor) && (factor ==0.5 || factor == 2 || factor == 3))
            {
                break;
            }
            Console.WriteLine("Invalid input. Please Input 0.5, 2 or 3.");
            Console.Write("Enter scaling factor(0.5, 2, or 3): ");
        }
        recipe.ScaleRecipe(factor); Console.WriteLine("Recipe scaled successfully.");
    }
    //ResetQuantities method resets the quantities of ingredients in a given recipe to their original values.

    static void ResetQuantites(Recipe recipe)
    {
        if (recipe == null)
        {
            Console.WriteLine("No recipe entered yet.");
            return;
        }
        recipe.ResetQuantities();
        Console.WriteLine("Quantites reeset to Original values.");
    }

    //ClearData method clears all data associated with a given recipe.

    static void ClearData(Recipe recipe)
    {
        if (recipe == null)
        { 
        Console.WriteLine("No recipe entered yet.");
        return;
    }
    recipe.ClearData();
        Console.WriteLine("Recipe data cleared.");
        }
}

